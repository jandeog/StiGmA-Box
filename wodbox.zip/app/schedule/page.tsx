// app/schedule/page.tsx
export default function SchedulePage() {
  const demoClasses = [
    { time: "07:00", coach: "Maria", capacity: "12/16" },
    { time: "09:00", coach: "Nikos", capacity: "10/16" },
    { time: "18:00", coach: "Eleni", capacity: "16/16 (Full)" },
  ];

  return (
    <section>
      <h1 className="text-2xl font-bold mb-4">Schedule (demo)</h1>
      <ul className="space-y-2">
        {demoClasses.map((c) => (
          <li key={c.time} className="border border-zinc-800 rounded p-3 bg-zinc-900 flex items-center justify-between">
            <div>
              <div className="font-medium">{c.time}</div>
              <div className="text-sm text-zinc-400">Coach: {c.coach}</div>
            </div>
            <button className="text-sm px-3 py-1 rounded border border-zinc-700 hover:bg-zinc-800">
              Book
            </button>
            <div className="text-sm text-zinc-300">{c.capacity}</div>
          </li>
        ))}
      </ul>
      <p className="text-xs text-zinc-400 mt-3">* Sample data to illustrate the flow.</p>
    </section>
  );
}
