// app/athletes/add/page.tsx
'use client';

import { useEffect, useMemo, useState } from 'react';

type Gender = 'male' | 'female' | 'other' | 'prefer_not_say';

export type Athlete = {
  id: string;
  firstName: string;        // *
  lastName: string;         // *
  nickname?: string;        // optional
  teamName?: string;        // optional
  dob: string;              // * ISO (YYYY-MM-DD)
  email: string;            // *
  phone: string;            // *
  gender?: Gender;          // optional
  heightCm?: number;        // optional
  weightKg?: number;        // optional
  yearsOfExperience?: number; // optional (numeric)
  credits?: number;         // optional (numeric)
  notes?: string;           // optional
  emergencyName?: string;   // optional
  emergencyPhone?: string;  // optional
  createdAt: string;        // ISO
  updatedAt: string;        // ISO
};

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phoneRe = /^[\d+\-\s()]{6,20}$/;
const keyAthletes = 'athletes';

export default function AddAthletePage() {
  // required
  const [firstName, setFirstName]   = useState('');
  const [lastName, setLastName]     = useState('');
  const [dob, setDob]               = useState(''); // YYYY-MM-DD
  const [email, setEmail]           = useState('');
  const [phone, setPhone]           = useState('');

  // new optional
  const [teamName, setTeamName]     = useState('');
  const [nickname, setNickname]     = useState('');
  const [years, setYears]           = useState<string>(''); // numeric input → number on save
  const [credits, setCredits]       = useState<string>(''); // numeric input → number on save

  // other optional
  const [gender, setGender]         = useState<Gender | ''>('');
  const [heightCm, setHeightCm]     = useState<string>('');
  const [weightKg, setWeightKg]     = useState<string>('');
  const [notes, setNotes]           = useState('');
  const [emName, setEmName]         = useState('');
  const [emPhone, setEmPhone]       = useState('');

  const [savedMsg, setSavedMsg]     = useState('');
  const [errors, setErrors]         = useState<Record<string, string>>({});
  const [athletes, setAthletes]     = useState<Athlete[]>([]);

  useEffect(() => {
    const raw = localStorage.getItem(keyAthletes);
    setAthletes(raw ? (JSON.parse(raw) as Athlete[]) : []);
  }, []);

  const fullName = useMemo(
    () => [firstName.trim(), lastName.trim()].filter(Boolean).join(' '),
    [firstName, lastName]
  );

  const validate = () => {
    const e: Record<string, string> = {};
    if (!firstName.trim()) e.firstName = 'Required';
    if (!lastName.trim())  e.lastName = 'Required';
    if (!dob)              e.dob = 'Required';
    if (!emailRe.test(email.trim())) e.email = 'Invalid email';
    if (!phoneRe.test(phone.trim())) e.phone = 'Invalid phone';
    if (years && isNaN(Number(years))) e.years = 'Must be a number';
    if (credits && isNaN(Number(credits))) e.credits = 'Must be a number';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const save = (a: Athlete[]) => {
    setAthletes(a);
    localStorage.setItem(keyAthletes, JSON.stringify(a));
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const now = new Date().toISOString();
    const id  = crypto.randomUUID();

    // prevent duplicates by email OR exact full name
    const exists = athletes.some(
      x => x.email.toLowerCase() === email.trim().toLowerCase()
        || ([x.firstName, x.lastName].join(' ').toLowerCase() === fullName.toLowerCase())
    );
    if (exists) {
      setSavedMsg('⚠️ Athlete already exists (same email or name).');
      setTimeout(() => setSavedMsg(''), 2000);
      return;
    }

    const rec: Athlete = {
      id,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      nickname: nickname.trim() || undefined,
      teamName: teamName.trim() || undefined,
      dob,
      email: email.trim(),
      phone: phone.trim(),
      gender: gender || undefined,
      heightCm: heightCm ? Number(heightCm) : undefined,
      weightKg: weightKg ? Number(weightKg) : undefined,
      yearsOfExperience: years ? Number(years) : undefined,
      credits: credits ? Number(credits) : undefined,
      notes: notes || undefined,
      emergencyName: emName || undefined,
      emergencyPhone: emPhone || undefined,
      createdAt: now,
      updatedAt: now,
    };

    const next = [rec, ...athletes].sort((a, b) =>
      a.lastName.localeCompare(b.lastName) || a.firstName.localeCompare(b.firstName)
    );
    save(next);

    setSavedMsg(`✅ Saved: ${rec.firstName} ${rec.lastName}`);
    setTimeout(() => setSavedMsg(''), 1800);

    // clear form
    setFirstName(''); setLastName(''); setDob('');
    setEmail(''); setPhone('');
    setTeamName(''); setNickname('');
    setYears(''); setCredits('');
    setGender(''); setHeightCm(''); setWeightKg('');
    setNotes(''); setEmName(''); setEmPhone('');
    setErrors({});
  };

  return (
    <section className="max-w-2xl">
      <h1 className="text-2xl font-bold mb-4">Add Athlete</h1>

      <form onSubmit={onSubmit} className="space-y-5">
        {/* Identity */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-sm mb-1 text-zinc-300">First name <span className="text-red-400">*</span></label>
            <input
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
              placeholder="e.g. Giannis"
            />
            {errors.firstName && <div className="text-xs text-red-400 mt-1">{errors.firstName}</div>}
          </div>
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Last name <span className="text-red-400">*</span></label>
            <input
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
              placeholder="e.g. Antetokounmpo"
            />
            {errors.lastName && <div className="text-xs text-red-400 mt-1">{errors.lastName}</div>}
          </div>
        </div>

        {/* Team + Nickname */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Team name</label>
            <input
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
              placeholder="e.g. Red"
            />
          </div>
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Nickname</label>
            <input
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
              placeholder="e.g. Air"
            />
          </div>
        </div>

        {/* Contact (admin preset in real flow; demo: we fill it) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Email <span className="text-red-400">*</span></label>
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
              placeholder="name@example.com"
            />
            {errors.email && <div className="text-xs text-red-400 mt-1">{errors.email}</div>}
          </div>
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Phone <span className="text-red-400">*</span></label>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
              placeholder="+30 69..."
            />
            {errors.phone && <div className="text-xs text-red-400 mt-1">{errors.phone}</div>}
          </div>
        </div>

        {/* DOB + Gender */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Date of birth <span className="text-red-400">*</span></label>
            <input
              type="date"
              value={dob}
              onChange={(e) => setDob(e.target.value)}
              className="datepicker-white-icon w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
            />
            {errors.dob && <div className="text-xs text-red-400 mt-1">{errors.dob}</div>}
          </div>
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Gender</label>
            <select
              value={gender}
              onChange={(e) => setGender(e.target.value as Gender | '')}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
            >
              <option value="">—</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
              <option value="prefer_not_say">Prefer not to say</option>
            </select>
          </div>
        </div>

        {/* Body metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Height (cm)</label>
            <input
              inputMode="numeric"
              value={heightCm}
              onChange={(e) => setHeightCm(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
              placeholder="e.g. 182"
            />
          </div>
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Weight (kg)</label>
            <input
              inputMode="numeric"
              value={weightKg}
              onChange={(e) => setWeightKg(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
              placeholder="e.g. 85"
            />
          </div>
        </div>

        {/* Experience (numeric) + Credits */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Years of experience</label>
            <input
              inputMode="numeric"
              value={years}
              onChange={(e) => setYears(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
              placeholder="e.g. 3"
            />
            {errors.years && <div className="text-xs text-red-400 mt-1">{errors.years}</div>}
          </div>
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Credits</label>
            <input
              inputMode="numeric"
              value={credits}
              onChange={(e) => setCredits(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
              placeholder="e.g. 10"
            />
            {errors.credits && <div className="text-xs text-red-400 mt-1">{errors.credits}</div>}
          </div>
        </div>

        {/* Notes */}
        <div>
          <label className="block text-sm mb-1 text-zinc-300">Notes (injuries, allergies, etc.)</label>
          <textarea
            rows={4}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
            placeholder="Optional info for the coach"
          />
        </div>

        {/* Emergency contact */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Emergency contact name</label>
            <input
              value={emName}
              onChange={(e) => setEmName(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm mb-1 text-zinc-300">Emergency contact phone</label>
            <input
              value={emPhone}
              onChange={(e) => setEmPhone(e.target.value)}
              className="w-full rounded border border-zinc-700 bg-zinc-900 px-3 py-2"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button className="px-4 py-2 rounded border border-zinc-700 hover:bg-zinc-800 text-sm">
            Save athlete
          </button>
          {savedMsg && <span className="text-sm text-zinc-300">{savedMsg}</span>}
        </div>
      </form>

      <hr className="my-6 border-zinc-800" />

      {/* small list for demo */}
      <h2 className="text-lg font-semibold mb-2">Athletes (demo)</h2>
      <div className="border border-zinc-800 rounded">
        {athletes.length === 0 ? (
          <div className="p-3 text-sm text-zinc-400">No athletes yet.</div>
        ) : (
          <ul className="divide-y divide-zinc-800">
            {athletes.map((a) => (
              <li key={a.id} className="p-3 flex items-center justify-between">
                <div>
                  <div className="font-medium">
                    {a.firstName} {a.lastName}
                    {a.nickname ? <span className="text-zinc-400"> ({a.nickname})</span> : null}
                    {a.teamName ? <span className="text-zinc-500 text-xs ml-2">[{a.teamName}]</span> : null}
                  </div>
                  <div className="text-xs text-zinc-500">{a.email} • {a.phone}</div>
                </div>
                <div className="text-xs text-zinc-500">{a.dob}</div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
